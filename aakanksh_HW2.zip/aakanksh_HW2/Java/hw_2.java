import java.util.HashMap;
import java.util.Map;
import java.util.Stack;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Reader;
import java.lang.Integer;
import javax.print.DocFlavor.INPUT_STREAM;
import javax.swing.Spring;
//HOMEWORK 2 IS COMPLETLY DONE 

public class hw_2{

	public enum pushType {NUM, STRING ,NAME;}

	//THIS IS PART ONE 1-12 OF THE HOMEWORK ON JAVA AND IS NOW COMPLETED. CONVERT THE SAME LOGIC INTO PYTHON BY 20TH OF JULY.
	public static boolean isNumeric(String str)
	{
		for (int index = 0 ; index <= str.length()-1; index++){
			char c = str.charAt(index);
			if (!Character.isDigit(c)) return false;
		}
		return true;
	}
	public static Stack<Object> push_num_(String x,Stack<Object> myStack,Map<Object, pushType> myMap){
		String number = "" ;
		for (int index = 5; index <= x.length()-1 ; index++){ //the reason it is index 4 is push 
			number += x.charAt(index);   
			if (x.charAt(index) == '-' && index == 5){
				index = index;
			}
			else if(x.charAt(5) >= 'a'&& x.charAt(5) <= 'z'|x.charAt(5) >= 'A'&& x.charAt(5) <= 'Z'|x.charAt(5) >= 'A'&& x.charAt(5) <= 'z'){              //checking for the first thing after push be a letter 
				String stringInput = x.substring(5, x.length()); 
				myStack.push(stringInput);
				index = x.length();
				myMap.put(stringInput, pushType.NAME);

			}
			//parses through the string and collects the number.  
			else if(index == x.length()-1 && (isNumeric(number)|isNumeric(number.substring(1,number.length())))){
				int result = Integer.parseInt(number,10);  //converts string to int. 
				if (x.charAt(5)==('-')){
					result = -result; 
				      myStack.push(result);
				}
				myStack.push(result);
				
				myMap.put(result,pushType.NUM);//Pushes the number on to the stack. 
			}
			else if (index != x.length()-1 && (isNumeric(number)|isNumeric(number.substring(1,number.length())))){
				index = index;
			}

			else if(x.charAt(5)== '\"' && x.charAt(x.length()-1)== '\"' ){
				String stringInput = x.substring(6, x.length()-1); 
				int indexString =0;
				while(indexString < stringInput.length()){
					if(stringInput.charAt(indexString)== '\"'){
						myStack.push(":error:");
					}
					indexString++;
				}
				myStack.push(stringInput);
				index = x.length();
				myMap.put(stringInput, pushType.STRING);
			}
			
			else  {
				myStack.push(":error:");
			}
		}	
		return myStack; 
	} // COMPLETED PUSH_NUM_

	public static Stack<Object> pop(Stack<Object> mystack){
		if (!mystack.isEmpty()){
			mystack.pop();
		}
		else {
			mystack.push(":error:");
		}
		return mystack;
		//this function is complete. 
	}
	public static Stack<Object> Boolean (String input,Stack<Object> mystack){
		if (input.equals(":true:")){
			mystack.push(":true:");
		}
		else if (input.equals(":false:")){
			mystack.push(":false:");
		}
		else {
			mystack.push(":error:");
		}
		return mystack;
		//Boolean is complete.
	}

	public static Stack<Object> error (String input,Stack<Object> mystack){
		mystack.push(":error:");
		return mystack;
		// Error is complete but check again 
	}

	public static Stack<Object> add (Stack<Object> mystack){
		if (mystack.isEmpty()){
			mystack.push(":error:");
			return mystack;
		}

		Object Obj1 = mystack.peek();
		if (Obj1.getClass() == java.lang.Integer.class ){
			String input1 = mystack.pop().toString();
			if (mystack.isEmpty()){
				mystack.push(":error:");
				mystack.push(Obj1);
				return mystack;
			}
			Obj1 = mystack.peek();
			if (Obj1.getClass() == java.lang.Integer.class && !mystack.isEmpty()){
				String input2 = mystack.pop().toString();
				int sum = Integer.parseInt(input1, 10) + Integer.parseInt(input2, 10);
				mystack.push(sum);
			}
			else {
				mystack.push(":error:");
				mystack.push(input1);
			}
		}
		else {
			mystack.push(":error:");
		}
		return mystack;
		//complete the add methods also add errors .
	}



	public static Stack<Object> sub (Stack<Object> mystack){
		if (mystack.isEmpty()){
			mystack.push(":error:");
			return mystack;
		}
		Object Obj1 = mystack.peek();
		if (Obj1.getClass() == java.lang.Integer.class){
			String input1 = mystack.pop().toString();
			if (mystack.isEmpty()){
				mystack.push(":error:");
				mystack.push(Obj1);
				return mystack;
			}
			Obj1 = mystack.peek();
			if (Obj1.getClass() == java.lang.Integer.class && !mystack.isEmpty()){
				String input2 = mystack.pop().toString();
				int sum = Integer.parseInt(input2, 10) - Integer.parseInt(input1, 10);
				mystack.push(sum);
			}
			else {
				mystack.push(":error:");
				mystack.push(input1);
			}
		}
		else {
			mystack.push(":error:");
		}
		return mystack;
		//complete the sub methods also add errors .
	}


	public static Stack<Object> mul (Stack<Object> mystack){
		if (mystack.isEmpty()){
			mystack.push(":error:");
			return mystack;
		}

		Object Obj1 = mystack.peek();
		if (Obj1.getClass() == java.lang.Integer.class ){
			String input1 = mystack.pop().toString();
			if (mystack.isEmpty()){
				mystack.push(":error:");
				mystack.push(Obj1);
				return mystack;
			}
			Obj1 = mystack.peek();
			if (Obj1.getClass() == java.lang.Integer.class && !mystack.isEmpty()){
				String input2 = mystack.pop().toString();
				int sum = Integer.parseInt(input2, 10) * Integer.parseInt(input1, 10);
				mystack.push(sum);
			}
			else {
				
				mystack.push(":error:");
				mystack.push(input1);
			}
		}
		else {
			mystack.push(":error:");
		}
		return mystack;
		//complete the mul methods also add errors .
	}

	public static Stack<Object> div (Stack<Object> mystack){
		Object Obj1 = mystack.peek();
		if (Obj1.getClass() == java.lang.Integer.class ){
			String input1 = mystack.pop().toString();
			if (mystack.isEmpty()){
				mystack.push(":error:");
				mystack.push(Obj1);
				return mystack;
			}
			Obj1 = mystack.peek();
			if (Obj1.getClass() == java.lang.Integer.class && !mystack.isEmpty()){
				String input2 = mystack.pop().toString();
				int sum = Integer.parseInt(input2, 10) / Integer.parseInt(input1, 10);
				mystack.push(sum);
			}
			else {
				
				mystack.push(":error:");
				mystack.push(input1);
			}
		}
		else {
			mystack.push(":error:");
		}
		return mystack;
		//complete the div methods also add errors .
	}



	public static Stack<Object> rem (Stack<Object> mystack){
		if (mystack.isEmpty()){
			mystack.push(":error:");
			return mystack;
		}

		Object Obj1 = mystack.peek();
		if (Obj1.getClass() == java.lang.Integer.class ){
			String input1 = mystack.pop().toString();
			Obj1 = mystack.peek();
			if (Obj1.getClass() == java.lang.Integer.class && !mystack.isEmpty()){
				String input2 = mystack.pop().toString();
				int sum = Integer.parseInt(input2, 10) % Integer.parseInt(input1, 10);
				mystack.push(sum);
			}
			else {
				mystack.push(input1);
				mystack.push(":error:");
			}
		}
		else {
			mystack.push(":error:");
		}
		return mystack;
		//complete the rem methods also add errors .
	}


	public static Stack<Object> neg (Stack<Object> mystack){
		if (mystack.isEmpty()){
			mystack.push(":error:");
			return mystack;
		}

		Object Obj1 = mystack.peek();
		if (Obj1.getClass() == java.lang.Integer.class && !mystack.isEmpty()){
			String input1 = mystack.pop().toString();
			int sum = Integer.parseInt(input1, 10);
			int neg = -sum;
			mystack.push(neg);
		}
		else {
			mystack.push(":error:");
		}
		return mystack;

	}

	public static Stack<Object> swap (Stack<Object> mystack){
		if (!mystack.isEmpty()){
			Object input1 = mystack.pop();
			if (!mystack.isEmpty()){
				Object input2 = mystack.pop();
				mystack.push(input1);
				mystack.push(input2);
			}
			else {
				mystack.push(input1);
				mystack.push(":error:");
			}
		}
		else {
			mystack.push(":error:");
		}
		return mystack;

	}

	public static void quit(Stack<Object> myStack,FileOutputStream out) throws IOException{
		if (myStack.isEmpty()){
			System.out.println("This Stack is empty");
		}
		else {
			OutputStreamWriter osw = new OutputStreamWriter(out);
			System.out.println("the name is " + out.getFD());
			while (!myStack.isEmpty()){
				osw.write(myStack.peek().toString());
				System.out.println("in quit" + myStack.peek());
				myStack.pop();
			}
			osw.close();
			//print every element in the stack
		}
	}

	public static void hw2(FileReader input, FileOutputStream output) throws IOException{
		BufferedReader in = new BufferedReader(input);
		FileOutputStream out = output;
		String line;
		Stack<Object> myStack = new Stack<>();
		Map<Object,pushType> myMap = new HashMap<>();

		while ((line = in.readLine())!= null){
			if (line.length() > 3 && line.substring(0,4).equals("push")){
				push_num_(line, myStack, myMap);
		
				//				push_string_literal(line, myStack, myMap);
				//		    	push_name_(line, myStack, myMap);

			}
			if (line.toString().equals("pop")){
				pop(myStack);
			}
			if (line.toString().equals(":true:") | line.toString().equals(":false:")){
				Boolean(line, myStack);
						}
			if (line.toString().equals(":error:")){
				error(line, myStack);
			}
			if (line.toString().equals("add")){
				add(myStack);
			}
			if (line.toString().equals("sub")){
				sub(myStack);
			}
			if (line.toString().equals("mul")){
				mul(myStack);
			}
			if (line.toString().equals("div")){
				div(myStack);
			}
			if (line.equals("rem")){
				rem(myStack);
			}
			if (line.toString().equals("neg")){
				neg(myStack);
			}
			if (line.toString().equals("swap")){
				swap(myStack);
			}
			if (line.toString().equals("quit")){
				quit(myStack,out);
			}
		}
	}
        public static void main(String [ ] args) throws IOException
	{
		FileReader input1 = new FileReader("sample_input1.txt");//correct
		FileOutputStream output1 = new FileOutputStream("sample_output1.txt");
		hw_2.hw2(input1, output1);
		FileReader input2 = new FileReader("sample_input2.txt");//correct
		FileOutputStream output2 = new FileOutputStream("sample_output2.txt");
		hw_2.hw2(input2, output2);
		FileReader input3 = new FileReader("sample_input3.txt");//correct
		FileOutputStream output3 = new FileOutputStream("sample_output3.txt");
		hw_2.hw2(input3, output3);
		FileReader input4 = new FileReader("sample_input4.txt");//correct
		FileOutputStream output4 = new FileOutputStream("sample_output4.txt");
		hw_2.hw2(input4, output4);
		FileReader input5 = new FileReader("sample_input5.txt");//correct
		FileOutputStream output5 = new FileOutputStream("sample_output5.txt");
		hw_2.hw2(input5, output5);
		
		
		
		FileReader input6 = new FileReader("sample_input6.txt");
		FileOutputStream output6 = new FileOutputStream("sample_output6.txt");
		hw_2.hw2(input6, output6);


}

